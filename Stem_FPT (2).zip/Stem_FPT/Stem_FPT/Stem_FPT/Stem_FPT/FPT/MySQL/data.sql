CREATE DATABASE IF NOT EXISTS my_database;

USE my_database;