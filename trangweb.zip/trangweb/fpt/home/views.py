from django.shortcuts import render

def home(request):
    return render(request, 'home/home.html')

def about(request):
    return render(request, 'home/about.html')

def courses(request):
    return render(request, 'home/courses.html')

def contact(request):
    return render(request, 'home/contact.html')
